#include "func.h"
extern ID holeid;


void myhandler(int sig)
{
	printf("我接收到了SIGINT 信号，即将退出\n");

	int ret_shmdt=shmdt(holeid.shmaddr);
	if(ret_shmdt==-1)
	{
		perror("shmdt");
	}
	exit(0);
}

int main()
{
	signal(SIGINT,myhandler);

	holeid.A1pid=getpid();
	printf("my(A1) pid is : %d \n",holeid.A1pid);
	
/*              共享内存创建                    */
	int shmid=shmget(1234,4096,0600|IPC_CREAT);

	if(shmid==-1)
	{
		perror("shmget");
		return -1;
	}
	
	char *p=(char*)shmat(shmid,NULL,0);

	if((char*)-1==p)
	{
		perror("shmat");
		return -1;
	}


/*              共享内存创建                    */
	
/*				信号量创建						*/
	int semid=semget(1234,1,0600|IPC_CREAT);
	if(semid== -1)
	{
		perror("semget");
		return -1;
	}
	unsigned short arr=1;
	int ret_semctl;

	ret_semctl=semctl(semid,0,SETALL,&arr);
	if(ret_semctl==-1)
	{
		perror("semctl");
		return -1;
	}

	memset(&arr,0,sizeof(arr));

	
	ret_semctl=semctl(semid,0,GETALL,&arr);
	if(ret_semctl==-1)
	{
		perror("semctl");
		return -1;
	}

	printf("\nthe arr is %d \n",arr);

	struct sembuf sop,sov;
	sop.sem_num= 0;
	sop.sem_op= -1;
	sop.sem_flg= SEM_UNDO;
	sov.sem_num= 0;
	sov.sem_op=  1;
	sov.sem_flg= SEM_UNDO;

	printf("the semid is : %d\n",semid);
/*				信号量创建						*/
	char buf[128]={0};

	
		printf(" I'm A1\n");
	while(1){
		

		if(strlen(p)!=0){
		semop(semid,&sop,1);	
		
		if(strcmp(p,"Bleaved!")==0)
				kill(getpid(),SIGINT);

		printf("%s \n",p);
		memset(p,0,sizeof(p));
		semop(semid,&sov,1);
		}
	
	}
		
}
