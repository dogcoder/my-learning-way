#include "func.h"
extern ID holeid;
typedef struct msgbuf 
{
	long mtype;
	char buffer[128];
}mbuf;

int main()
{
	holeid.B1pid=getpid();
	printf("my(B1) pid is : %d \n",holeid.B1pid);

	struct msgbuf mp;
	memset(&mp,0,sizeof(struct msgbuf));
	int msgid=msgget(1234,0600|IPC_CREAT);
	if(msgid==-1)
	{
		perror("msgid");
		return -1;
	}
	printf("the msgid is : %d \n ",msgid);

	printf("I'm B1 \n");
	while(1)
	{
		int ret_rec=msgrcv(msgid,&mp,sizeof(mp.buffer),1,0);
		if(ret_rec==-1)
		{
			perror("amsgrcv");
			return -1;
		}

		if(mp.mtype==1)
		{
			puts(mp.buffer);
			memset(&mp,0,sizeof(struct msgbuf));
		}
	}
}
