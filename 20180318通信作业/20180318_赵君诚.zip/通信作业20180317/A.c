#include "func.h"

extern ID holeid;



void mymakefifo()
{
	if(mkfifo("./pipe1",0666))
	{
		perror("makefifo");
	}

	if(mkfifo("./pipe2",0666))
	{
		perror("makefifo");
	}
	printf("the pipe has been creat!\n");
}


void myhandler(int sig)
{
	printf("我已接收到结束信号，准备结束！\n");
	sleep(1);
	unlink("./pipe1");
	unlink("./pipe2");

	int ret_kill1=kill(holeid.Bpid,SIGINT);
	if(ret_kill1==-1)
	{
		perror("kill1");
	}
	printf("我将关闭A1，A1pid=%d \n",holeid.A1pid);
	int ret_kill2=kill(holeid.A1pid,SIGINT);
	if(ret_kill2==-1)
	{
		perror("kill2");
	}
	
	usleep(20);
	int ret_shmdt=shmdt(*(holeid.shmaddr));
	if(ret_shmdt==-1)
	{
		perror("shmdt");
	}

	int ret_dlm=shmctl(holeid.shmid,IPC_RMID,NULL);
	if(ret_dlm==-1)
	{
		perror("shmctl");
	}
	
	int ret_delsem=semctl(holeid.semid,IPC_RMID,0);
	if(ret_delsem==-1)
	{
		perror("semctl");
	}
	exit(0);
}

int main(int argc,char *argv[])
{
	
	printf("A1pid=%d \n",holeid.A1pid);
	signal(SIGINT,myhandler);

	int pid=getpid();
	holeid.Apid=pid;
	printf("my(A) pid is :%d\n",holeid.Apid);

/*      			管道创建					*/
	mymakefifo();									//创建管道文件
	int fdr,fdw;
	
	if(fdw=open("./pipe1",O_WRONLY))				//打开管道文件 ，写 1 读 2
	{
		perror("open");
	}
	if(fdr=open("./pipe2",O_RDONLY))
	{
		perror("open");
	}
/*      			管道创建					*/
/*              共享内存创建                    */
	int shmid=shmget(1234,4096,0600|IPC_CREAT);

	if(shmid==-1)
	{
		perror("shmget");
		return -1;
	}

	holeid.shmid=shmid;
	printf("the shmid is :%d \n",holeid.shmid);

	char *p=(char*)shmat(shmid,NULL,0);
	holeid.shmaddr=&p;
	if((char*)-1==p)
	{
		perror("shmat");
		return -1;
	}
	memset(p,0,sizeof(p));
/*              共享内存创建                    */
/*				信号量创建						*/
	int semid=semget(1234,1,0600|IPC_CREAT);
	if(semid== -1)
	{
		perror("semget");
		return -1;
	}
	unsigned short arr=1;
	int ret_semctl;

	ret_semctl=semctl(semid,0,SETALL,&arr);
	if(ret_semctl==-1)
	{
		perror("semctl");
		return -1;
	}

	memset(&arr,0,sizeof(arr));

	
	ret_semctl=semctl(semid,0,GETALL,&arr);
	if(ret_semctl==-1)
	{
		perror("semctl");
		return -1;
	}

	printf("\nthe arr is %d \n",arr);

	struct sembuf sop,sov;
	sop.sem_num= 0;
	sop.sem_op= -1;
	sop.sem_flg= SEM_UNDO;
	sov.sem_num= 0;
	sov.sem_op=  1;
	sov.sem_flg= SEM_UNDO;

	holeid.semid=semid;
	printf("the semid is : %d \n",holeid.semid);

/*				信号量创建						*/
	char buf[128]={0};
	fd_set rdset;

	while(1)
	{
		bzero(buf,sizeof(buf));
		FD_ZERO(&rdset);
		FD_SET(0,&rdset);
		FD_SET(fdr,&rdset);
		int ret_select=select(fdr+1,&rdset,NULL,NULL,NULL);

		if(ret_select>0)
		{
			if(ret_select==-1)
			{
				perror("select");
				return -1;
			}

			if(FD_ISSET(0,&rdset))				//键盘有输入
			{
				bzero(buf,sizeof(buf));
				int ret_read=read(0,buf,sizeof(buf)-1);
				if(ret_read==-1)
				{
					perror("read");
					return -1;
				}
				write(fdw,buf,sizeof(buf)-1);	//将键盘输入  写进 管道
				
				char abuf[128];
				sprintf(abuf,"myself(A): %s",buf);
				semop(semid,&sop,1);				//将键盘输入 写进 共享内存 并信号量加锁
				memset(p,0,sizeof(p));
				memcpy(p,abuf,sizeof(abuf)-1);
				semop(semid,&sov,1);

			}


			if(FD_ISSET(fdr,&rdset))			//读管道有输入
			{
				bzero(buf,sizeof(buf));
				int ret_rd_fdr=read(fdr,buf,sizeof(buf)-1);
				if(ret_rd_fdr==-1)
				{
					perror("read");
					return -1;
				}
				if(ret_rd_fdr==0)
				{
					printf("B已下线\n");
					
				semop(semid,&sop,1);	//通知 A1,B已经下线！	
				memset(p,0,sizeof(p));
				memcpy(p,"Bleaved!\0",9);
				semop(semid,&sov,1);
				kill(getpid(),SIGINT);
					break;
				}
				printf("B:%s \n",buf);			//显示屏输出管道内容
				char bbuf[128];
				sprintf(bbuf,"B: %s",buf);
				semop(semid,&sop,1);				//将管道内容 写进 共享内存 并信号量加锁
				memset(p,0,sizeof(p));
				memcpy(p,bbuf,sizeof(bbuf)-1);
				semop(semid,&sov,1);

			}
		}
	}

	close(fdr);
	close(fdw);

	return 0;
}

