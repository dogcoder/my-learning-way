#include "func.h"

extern ID holeid;

typedef struct msgbuf
{
	long mtype;
	char buffer[128];
}mbuf;



void mymakefifo()
{
	if(mkfifo("./pipe1",0666))
	{
		perror("makefifo");
	}

	if(mkfifo("./pipe2",0666))
	{
		perror("makefifo");
	}
}

void myhandler(int sig)
{
	sleep(1);
	unlink("./pipe1");
	unlink("./pipe2");

	int ret_kill1=kill(holeid.Apid,SIGINT);
	if(ret_kill1==-1)
	{
		perror("kill1");
	}
	printf("我将关闭B1，B1pid=%d \n",holeid.B1pid);
	int ret_kill2=kill(holeid.B1pid,SIGINT);
	if(ret_kill2==-1)
	{
		perror("kill2");
	}
	
	int ret_delms=msgctl(holeid.msgid,IPC_RMID,NULL);
	if(ret_delms==-1)
	{
		perror("msgctl");
	}

	exit(0);
}



int main()
{
	printf("B1pid is : %d \n",holeid.B1pid);
	signal(SIGINT,myhandler);

	int pid=getpid();
	
	holeid.Bpid=pid;
	printf("my(B) pid is :%d\n",holeid.Bpid);

	mymakefifo();										//创建管道文件
	int fdr,fdw;

	if(fdr=open("./pipe1",O_RDONLY))					//打开管道文件 ，写 2 读 1
	{
		perror("open");
	}
	if(fdw=open("./pipe2",O_WRONLY))
	{
		perror("open");
	}
	/*					创建消息队列						*/

	mbuf mp;
	memset(&mp,0,sizeof(mbuf));
	int msgid=msgget(1234,0600|IPC_CREAT);
	if(msgid==-1)
	{
		perror("msgget");
		return -1;
	}
	
	holeid.msgid=msgid;
	printf("the msgid is : %d \n",holeid.msgid);

	/*					创建消息队列						*/	

	char buf[128]={0};
	fd_set rdset;

	while(1)
	{
		bzero(buf,sizeof(buf));
		FD_ZERO(&rdset);
		FD_SET(0,&rdset);
		FD_SET(fdr,&rdset);

		char buf[128]={0};
		fd_set rdset;

		while(1)
		{
			bzero(buf,sizeof(buf));
			FD_ZERO(&rdset);
			FD_SET(0,&rdset);
			FD_SET(fdr,&rdset);
			int ret_select=select(fdr+1,&rdset,NULL,NULL,NULL);

			if(ret_select>0)
			{
				if(ret_select==-1)
				{
					perror("select");
					return -1;
				}

				if(FD_ISSET(0,&rdset))				//键盘有输入
				{
					bzero(buf,sizeof(buf));
					int ret_read=read(0,buf,sizeof(buf)-1);
					if(ret_read==-1)
					{
						perror("read");
						return -1;
					}
					write(fdw,buf,sizeof(buf)-1);

					char bbuf[128]={0};
					sprintf(bbuf,"myself(B): %s",buf);
					memset(&mp,0,sizeof(mp));
					mp.mtype=1;											//将键盘输入传递给B1
					strcpy(mp.buffer,bbuf);
					int ret_send=msgsnd(msgid,&mp,sizeof(mp.buffer),0);
					if(ret_send==-1)
					{
						perror("msgsnd");
						return -1;
					}

				}


				if(FD_ISSET(fdr,&rdset))			//读管道有输入
				{
					bzero(buf,sizeof(buf));
					int ret_rd_fdr=read(fdr,buf,sizeof(buf)-1);
					if(ret_rd_fdr==-1)
					{
						perror("read");
						return -1;
					}
					if(ret_rd_fdr==0)
					{
						printf("A已经下线\n");
						memset(&mp,0,sizeof(mp));
						mp.mtype=1;
						strcpy(mp.buffer,"A已经下线\n");
						msgsnd(msgid,&mp,sizeof(mp.buffer),0);
						kill(getpid(),SIGINT);
		//				break;
					}
					printf("A:%s \n",buf);

					char abuf[128]={0};									//将管道输入 传输给B1
					memset(&mp,0,sizeof(mp));	
					mp.mtype=1;
					sprintf(abuf,"A: %s",buf);
					strcpy(mp.buffer,abuf);
					int ret_send=msgsnd(msgid,&mp,sizeof(mp.buffer),0);

				}
			}
		}

		close(fdr);
		close(fdw);

		return 0;
	}
}
